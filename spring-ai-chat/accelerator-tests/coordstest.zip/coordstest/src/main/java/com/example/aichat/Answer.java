package com.example.aichat;

public record Answer(String answer) {
}
