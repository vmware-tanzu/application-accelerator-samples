package com.example.aichat;

public record Question(String question) {
}
